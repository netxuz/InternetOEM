/* ============================================================ */
/*   Database name:  Modelo_Adm_MeetSite                        */
/*   DBMS name:      Microsoft SQL Server 6.x                   */
/*   Created on:     07-09-2010  9:57                           */
/* ============================================================ */

if exists (select 1
            from  sysobjects
           where  id = object_id('cmr_contenido_grupos')
            and   type = 'U')
   drop table cmr_contenido_grupos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cmr_contenido_usuario')
            and   type = 'U')
   drop table cmr_contenido_usuario
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cmr_nodos_grupos')
            and   type = 'U')
   drop table cmr_nodos_grupos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cmr_nodos_usuarios')
            and   type = 'U')
   drop table cmr_nodos_usuarios
go

if exists (select 1
            from  sysobjects
           where  id = object_id('wb_version_contenido')
            and   type = 'U')
   drop table wb_version_contenido
go

if exists (select 1
            from  sysobjects
           where  id = object_id('syr_info_usuarios')
            and   type = 'U')
   drop table syr_info_usuarios
go

if exists (select 1
            from  sysobjects
           where  id = object_id('syr_perfiles_usuarios')
            and   type = 'U')
   drop table syr_perfiles_usuarios
go

if exists (select 1
            from  sysobjects
           where  id = object_id('syr_grupo_usuarios')
            and   type = 'U')
   drop table syr_grupo_usuarios
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cms_archivos')
            and   type = 'U')
   drop table cms_archivos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cms_contenidos')
            and   type = 'U')
   drop table cms_contenidos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cms_nodos')
            and   type = 'U')
   drop table cms_nodos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_usuario')
            and   type = 'U')
   drop table sys_usuario
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_tipo_usuario')
            and   type = 'U')
   drop table sys_tipo_usuario
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_campo_usuarios')
            and   type = 'U')
   drop table sys_campo_usuarios
go

if exists (select 1
            from  sysobjects
           where  id = object_id('cms_template')
            and   type = 'U')
   drop table cms_template
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_perfiles')
            and   type = 'U')
   drop table sys_perfiles
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_grupos')
            and   type = 'U')
   drop table sys_grupos
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_parametros')
            and   type = 'U')
   drop table sys_parametros
go

if exists (select 1
            from  sysobjects
           where  id = object_id('wb_destacados_portal')
            and   type = 'U')
   drop table wb_destacados_portal
go

/* ============================================================ */
/*   Table: wb_destacados_portal                                */
/* ============================================================ */
create table wb_destacados_portal
(
    cod_destacados    numeric(10)           not null,
    tipo_destacados   numeric(10)           null    ,
    ord_destacados    numeric(10)           null    ,
    constraint PK_WB_DESTACADOS_PORTAL primary key (cod_destacados)
)
go

/* ============================================================ */
/*   Table: sys_parametros                                      */
/* ============================================================ */
create table sys_parametros
(
    cod_codigo        numeric(25)           not null,
    nom_parametro     varchar(255)          null    ,
    valor_parametro   varchar(255)          null    ,
    show_parametro    char(1)               null    ,
    constraint PK_SYS_PARAMETROS primary key (cod_codigo)
)
go

/* ============================================================ */
/*   Table: sys_grupos                                          */
/* ============================================================ */
create table sys_grupos
(
    cod_grupo         numeric(25)           not null,
    nom_grupo         varchar(255)          null    ,
    est_grupo         char(1)               null    ,
    constraint PK_SYS_GRUPOS primary key (cod_grupo)
)
go

/* ============================================================ */
/*   Table: sys_perfiles                                        */
/* ============================================================ */
create table sys_perfiles
(
    cod_perfil        numeric(25)           not null,
    nom_perfil        varchar(225)          null    ,
    est_perfil        char(1)               null    ,
    constraint PK_SYS_PERFILES primary key (cod_perfil)
)
go

/* ============================================================ */
/*   Table: cms_template                                        */
/* ============================================================ */
create table cms_template
(
    cod_template      numeric(25)           not null,
    nom_template      varchar(100)          null    ,
    texto_template    text                  null    ,
    arch_template     varchar(200)          null    ,
    est_template      char(1)               null    ,
    constraint PK_CMS_TEMPLATE primary key (cod_template)
)
go

/* ============================================================ */
/*   Table: sys_campo_usuarios                                  */
/* ============================================================ */
create table sys_campo_usuarios
(
    cod_campo         numeric(25)           not null,
    nom_campo         varchar(255)          null    ,
    tipo_campo        char(3)               null    ,
    est_campo         char(1)               null    ,
    constraint PK_SYS_CAMPO_USUARIOS primary key (cod_campo)
)
go

/* ============================================================ */
/*   Table: sys_tipo_usuario                                    */
/* ============================================================ */
create table sys_tipo_usuario
(
    cod_tipo          numeric(25)           not null,
    nom_tipo          varchar(255)          null    ,
    constraint PK_SYS_TIPO_USUARIO primary key (cod_tipo)
)
go

/* ============================================================ */
/*   Table: sys_usuario                                         */
/* ============================================================ */
create table sys_usuario
(
    cod_usuario       numeric(25)           not null,
    cod_tipo          numeric(25)           null    ,
    nom_usuario       varchar(225)          null    ,
    ape_usuario       varchar(225)          null    ,
    eml_usuario       varchar(100)          null    ,
    login_usuario     varchar(100)          null    ,
    pwd_usuario       varchar(100)          null    ,
    est_usuario       char(1)               null    ,
    constraint PK_SYS_USUARIO primary key (cod_usuario)
)
go

/* ============================================================ */
/*   Table: cms_nodos                                           */
/* ============================================================ */
create table cms_nodos
(
    cod_nodo          numeric(25)           not null,
    cod_nodo_rel      numeric(25)           null    ,
    cod_usuario       numeric(25)           null    ,
    cod_template      numeric(25)           null    ,
    titulo_nodo       varchar(500)          null    ,
    texto_nodo        text                  null    ,
    date_nodo         datetime              null    ,
    est_nodo          char(1)               null    ,
    prv_nodo          integer               null    ,
    constraint PK_CMS_NODOS primary key (cod_nodo)
)
go

/* ============================================================ */
/*   Table: cms_contenidos                                      */
/* ============================================================ */
create table cms_contenidos
(
    cod_contenido     numeric(25)           not null,
    cod_nodo          numeric(25)           null    ,
    cod_usuario       numeric(25)           null    ,
    titulo_contenido  varchar(500)          null    ,
    texto_contenido   text                  null    ,
    date_contenido    datetime              null    ,
    est_contenido     char(1)               null    ,
    prv_contendio     integer               null    ,
    dest_contenido    integer               null    ,
    constraint PK_CMS_CONTENIDOS primary key (cod_contenido)
)
go

/* ============================================================ */
/*   Table: cms_archivos                                        */
/* ============================================================ */
create table cms_archivos
(
    cod_archivo       numeric(25)           not null,
    cod_archivo_rel   numeric(25)           null    ,
    cod_contenido     numeric(25)           null    ,
    nom_archivo       varchar(300)          null    ,
    des_archivo       text                  null    ,
    date_archivo      datetime              null    ,
    ext_archivo       varchar(10)           null    ,
    img_archivo       image                 null    ,
    constraint PK_CMS_ARCHIVOS primary key (cod_archivo)
)
go

/* ============================================================ */
/*   Table: syr_grupo_usuarios                                  */
/* ============================================================ */
create table syr_grupo_usuarios
(
    cod_usuario       numeric(25)           null    ,
    cod_grupo         numeric(25)           null    
)
go

/* ============================================================ */
/*   Table: syr_perfiles_usuarios                               */
/* ============================================================ */
create table syr_perfiles_usuarios
(
    cod_usuario       numeric(25)           null    ,
    cod_perfil        numeric(25)           null    
)
go

/* ============================================================ */
/*   Table: syr_info_usuarios                                   */
/* ============================================================ */
create table syr_info_usuarios
(
    cod_usuario       numeric(25)           null    ,
    cod_campo         numeric(25)           null    
)
go

/* ============================================================ */
/*   Table: wb_version_contenido                                */
/* ============================================================ */
create table wb_version_contenido
(
    cod_version       numeric(25)           not null,
    cod_archivo       numeric(25)           null    ,
    nom_archivo       varchar(300)          null    ,
    des_archivo       text                  null    ,
    date_archivo      datetime              null    ,
    ext_archivo       varchar(10)           null    ,
    img_archivo       image                 null    ,
    constraint PK_WB_VERSION_CONTENIDO primary key (cod_version)
)
go

/* ============================================================ */
/*   Table: cmr_nodos_usuarios                                  */
/* ============================================================ */
create table cmr_nodos_usuarios
(
    cod_nodo          numeric(25)           null    ,
    cod_usuario       numeric(25)           null    ,
    tipo              char(1)               null    
)
go

/* ============================================================ */
/*   Table: cmr_nodos_grupos                                    */
/* ============================================================ */
create table cmr_nodos_grupos
(
    cod_nodo          numeric(25)           null    ,
    cod_grupo         numeric(25)           null    ,
    tipo              char(1)               null    
)
go

/* ============================================================ */
/*   Table: cmr_contenido_usuario                               */
/* ============================================================ */
create table cmr_contenido_usuario
(
    cod_contenido     numeric(25)           null    ,
    cod_usuario       numeric(25)           null    ,
    tipo              char(1)               null    
)
go

/* ============================================================ */
/*   Table: cmr_contenido_grupos                                */
/* ============================================================ */
create table cmr_contenido_grupos
(
    cod_contenido     numeric(25)           null    ,
    cod_grupo         numeric(25)           null    ,
    tipo              char(1)               null    
)
go

alter table sys_usuario
    add constraint FK_SYS_USUA_REF_1861_SYS_TIPO foreign key  (cod_tipo)
       references sys_tipo_usuario (cod_tipo)
go

alter table cms_nodos
    add constraint FK_CMS_NODO_REF_97_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table cms_nodos
    add constraint FK_CMS_NODO_REF_533_CMS_TEMP foreign key  (cod_template)
       references cms_template (cod_template)
go

alter table cms_contenidos
    add constraint FK_CMS_CONT_REF_122_CMS_NODO foreign key  (cod_nodo)
       references cms_nodos (cod_nodo)
go

alter table cms_contenidos
    add constraint FK_CMS_CONT_REF_126_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table cms_archivos
    add constraint FK_CMS_ARCH_REF_176_CMS_CONT foreign key  (cod_contenido)
       references cms_contenidos (cod_contenido)
go

alter table syr_grupo_usuarios
    add constraint FK_SYR_GRUP_REF_15_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table syr_grupo_usuarios
    add constraint FK_SYR_GRUP_REF_19_SYS_GRUP foreign key  (cod_grupo)
       references sys_grupos (cod_grupo)
go

alter table syr_perfiles_usuarios
    add constraint FK_SYR_PERF_REF_29_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table syr_perfiles_usuarios
    add constraint FK_SYR_PERF_REF_33_SYS_PERF foreign key  (cod_perfil)
       references sys_perfiles (cod_perfil)
go

alter table syr_info_usuarios
    add constraint FK_SYR_INFO_REF_1849_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table syr_info_usuarios
    add constraint FK_SYR_INFO_REF_1853_SYS_CAMP foreign key  (cod_campo)
       references sys_campo_usuarios (cod_campo)
go

alter table wb_version_contenido
    add constraint FK_WB_VERSI_REF_1875_CMS_ARCH foreign key  (cod_archivo)
       references cms_archivos (cod_archivo)
go

alter table cmr_nodos_usuarios
    add constraint FK_CMR_NODO_REF_1885_CMS_NODO foreign key  (cod_nodo)
       references cms_nodos (cod_nodo)
go

alter table cmr_nodos_usuarios
    add constraint FK_CMR_NODO_REF_1901_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table cmr_nodos_grupos
    add constraint FK_CMR_NODO_REF_1889_CMS_NODO foreign key  (cod_nodo)
       references cms_nodos (cod_nodo)
go

alter table cmr_nodos_grupos
    add constraint FK_CMR_NODO_REF_1910_SYS_GRUP foreign key  (cod_grupo)
       references sys_grupos (cod_grupo)
go

alter table cmr_contenido_usuario
    add constraint FK_CMR_CONT_REF_1893_CMS_CONT foreign key  (cod_contenido)
       references cms_contenidos (cod_contenido)
go

alter table cmr_contenido_usuario
    add constraint FK_CMR_CONT_REF_1905_SYS_USUA foreign key  (cod_usuario)
       references sys_usuario (cod_usuario)
go

alter table cmr_contenido_grupos
    add constraint FK_CMR_CONT_REF_1897_CMS_CONT foreign key  (cod_contenido)
       references cms_contenidos (cod_contenido)
go

alter table cmr_contenido_grupos
    add constraint FK_CMR_CONT_REF_1914_SYS_GRUP foreign key  (cod_grupo)
       references sys_grupos (cod_grupo)
go

